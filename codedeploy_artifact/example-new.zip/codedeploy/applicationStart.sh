cd /home/ubuntu/webapp/src
pwd
pm2 start server.js