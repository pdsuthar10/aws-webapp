cd /home/ubuntu
pwd
sudo chown ubuntu: webapp/src
sudo cp .env /home/ubuntu/webapp/src
pwd
cd /home/ubuntu/webapp/src
exit 2
npm install

